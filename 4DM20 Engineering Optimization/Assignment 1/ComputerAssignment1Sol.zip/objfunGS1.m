function f = objfunGS1(x)
% Objective function for Guided Selfstudy Assignment 1, question g) 

% Design variable values
x1= x(1);
x2= x(2);

% Objective function
f = 4*x1 + x2;

